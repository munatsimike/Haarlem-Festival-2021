as we did not receive any host account we are using local database
the database details are in the hfitteam4_db.sql file