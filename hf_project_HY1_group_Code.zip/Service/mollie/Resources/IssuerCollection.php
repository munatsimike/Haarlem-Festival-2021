<?php

namespace Mollie\Api\Resources;

class IssuerCollection extends BaseCollection
{
    /**
     * @return string|null
     */
    public function getCollectionResourceName()
    {
        return null;
    }
}