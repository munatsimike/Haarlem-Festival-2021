
<meta name="description" content="make online reservation for eating outside via our reservation system ">
<meta name="keywords" content="resrvation ,dinner outside , eating , European cuisine , dutch food , french food">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.js"></script>
<script>"https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"</script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="../../Css/style.css" type="text/css">
<script type="text/javascript" src= "/Service/NotifIt/js/notifIt.js"></script>
<link rel="stylesheet" type="text/css" href="/Service/NotifIt/css/notifIt.css">
<title>Haarlem festival</title>
