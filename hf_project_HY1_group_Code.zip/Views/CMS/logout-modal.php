<div class="modal bs-example-modal-m" id = "logoutModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-m">
    <div class="modal-content">
      <div class="modal-header justify-content-center"><h4>Logout <i id = "logoutIcon" class="bi bi-lock-fill icons"></i></h4></div>
      <div class="modal-body justify-content-center" ><p class="text-center h5">Are you sure you want to log-out ?</p></div>
      <div class="modal-footer"><a href="../../Service/CMS/logout.php" class="btn btn-primary btn-block">Logout</a></div>
    </div>
  </div>
</div>

 