
<footer>
    <i data-target="#volunteer-login" data-toggle = "modal"  class="bi bi-person-circle" id="login-icon" ></i>
	<p  class="footer">@HaarlemFestival</p> 
	<p class = "footer">Designed and built with love by Inholland University students: Group 4</p>
	<sapn><i class="bi bi-envelope-fill"></i></span>
	<span><i class="bi bi-facebook"></i></sapn>
	<span><i class="bi bi-twitter"></i></span>
</footer>