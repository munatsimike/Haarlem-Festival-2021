<?php
require_once "Enum.php";
use MyCLabs\Enum\Enum;

 Final class FormName extends Enum
{
    private const LOGIN = "login";
    private const REGISTRATION = "registration";
    private const PASSWORDRESET = "password-reset";
}

?>
