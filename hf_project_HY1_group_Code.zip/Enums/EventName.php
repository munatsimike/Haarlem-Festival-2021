<?php
require_once "Enum.php";
use MyCLabs\Enum\Enum;


 class EventName extends Enum
{
    const JAZZ = "Jazz";
    const DANCE = "Dance";
}

?>
